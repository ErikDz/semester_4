#### Welcome!
Welcome to my /TD2 directory! Here you will find 2 directories: default and international. Default contains the files for `hello-world` and international for `international-hello-world`.

The `international-hello-world`'s makefile makes the file with the language set to french.
