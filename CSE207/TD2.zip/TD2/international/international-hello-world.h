#ifndef HELLO_STRING_H
#define HELLO_STRING_H

#include <stdio.h>

//#define FRENCH
//#define SPANISH
//#define ENGLISH
//#define CHINESE
//#define DANISH

void print_hello_string();

#endif /* HELLO_STRING_H */
