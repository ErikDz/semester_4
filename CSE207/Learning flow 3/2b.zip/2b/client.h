// Header file for client.c
#ifndef CLIENT_H
#define CLIENT_H
#endif