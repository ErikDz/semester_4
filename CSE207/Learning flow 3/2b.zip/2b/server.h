// Header file for client.c
#ifndef SERVER_H
#define SERVER_H
#endif