// Header file for fancyclient.c
#ifndef FANCYCLIENT_H
#define FANCYCLIENT_H
#endif